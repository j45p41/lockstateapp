import mdurl = require("./build/index.cjs.js");

export = mdurl;
