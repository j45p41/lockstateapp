# Installation
> `npm install --save @types/linkify-it`

# Summary
This package contains type definitions for linkify-it (https://github.com/markdown-it/linkify-it).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/linkify-it.

### Additional Details
 * Last updated: Wed, 01 May 2024 18:07:45 GMT
 * Dependencies: none

# Credits
These definitions were written by [Lindsey Smith](https://github.com/praxxis), [Robert Coie](https://github.com/rapropos/typed-linkify-it), [Alex Plumb](https://github.com/alexplumb), and [Rafa Gares](https://github.com/ragafus).
