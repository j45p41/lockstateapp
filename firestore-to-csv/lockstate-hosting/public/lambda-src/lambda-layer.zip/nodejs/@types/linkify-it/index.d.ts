import LinkifyIt = require("./build/index.cjs.js");

export = LinkifyIt;
