import MarkdownIt = require("./dist/index.cjs.js");

export = MarkdownIt;
