# Installation
> `npm install --save @types/minimatch`

# Summary
This package contains type definitions for minimatch (https://github.com/isaacs/minimatch).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/minimatch.

### Additional Details
 * Last updated: Wed, 31 Aug 2022 17:32:44 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [vvakame](https://github.com/vvakame), [Shant Marouti](https://github.com/shantmarouti), and [BendingBender](https://github.com/BendingBender).
