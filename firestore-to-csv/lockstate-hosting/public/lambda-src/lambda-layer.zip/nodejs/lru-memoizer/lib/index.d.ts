import { asyncMemoizer } from './async';
export = asyncMemoizer;
