var convert = require('./convert'),
    func = convert('rest', require('../rest'));

func.placeholder = require('./placeholder');
module.exports = func;
