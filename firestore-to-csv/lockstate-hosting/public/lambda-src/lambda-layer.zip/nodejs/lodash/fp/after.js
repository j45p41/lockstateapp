var convert = require('./convert'),
    func = convert('after', require('../after'));

func.placeholder = require('./placeholder');
module.exports = func;
