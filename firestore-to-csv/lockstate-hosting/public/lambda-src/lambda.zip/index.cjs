'use strict';

/*  LockSure Alexa Smart Home Skill – 2025-07-07
 *  Single-file CommonJS for AWS Lambda.
 *  Standard Alexa Smart Home OAuth flow using Login with Amazon.
 *  Endpoints: /alexaAuth   /alexaToken   /smart-home
 *  Designed for API-Gateway "proxy" integration.
 */

/* ────────────────────────── 0. DEPS ─────────────────────────── */
const crypto  = require('crypto');
const admin   = require('firebase-admin');
const https   = require('https');
const http    = require('http');

// Simple fetch implementation using built-in modules
const fetch = (url, options = {}) => {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const isHttps = urlObj.protocol === 'https:';
    const client = isHttps ? https : http;
    
    const requestOptions = {
      hostname: urlObj.hostname,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method: options.method || 'GET',
      headers: options.headers || {}
    };

    const req = client.request(requestOptions, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        resolve({
          ok: res.statusCode >= 200 && res.statusCode < 300,
          status: res.statusCode,
          json: () => Promise.resolve(JSON.parse(data)),
          text: () => Promise.resolve(data)
        });
      });
    });

    req.on('error', reject);
    
    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
};

/* ───────────────────────── 1. CONFIG ────────────────────────── */
const {
  ALEXA_CLIENT_ID,
  ALEXA_CLIENT_SECRET,
  LWA_AUTH_URL  = 'https://www.amazon.com/ap/oa',
  LWA_TOKEN_URL = 'https://api.amazon.com/auth/o2/token',
  FB_SERVICE_ACCOUNT_JSON,
  FIREBASE_API_KEY
} = process.env;

const SKILL_ID       = 'amzn1.ask.skill.89751fb9-1b7f-4c40-8c9f-a5231bdb3998';
const API_BASE       = 'https://ayb2a2m447.execute-api.eu-west-1.amazonaws.com/prod';
const REDIRECT_URI   = `${API_BASE}/alexaAuth`;

/* ─────────────────────── 2. FIREBASE INIT ───────────────────── */
if (!admin.apps.length) {
  if (!FB_SERVICE_ACCOUNT_JSON)
    throw new Error('FB_SERVICE_ACCOUNT_JSON env-var missing');
  admin.initializeApp({
    credential: admin.credential.cert(JSON.parse(FB_SERVICE_ACCOUNT_JSON))
  });
}
const db = admin.firestore();

/* ─────────────── 3. SMALL HELPERS (pure functions) ──────────── */
const log = (lvl, msg, data) =>
  console.log(JSON.stringify({ ts: new Date().toISOString(), lvl, msg, data }));

const htmlLogin = (state, redirect) => /*html*/ `
<!DOCTYPE html><html><head><title>Locksure – Sign In</title></head>
<body style="font-family:sans-serif;max-width:410px;margin:40px auto;padding:24px">
  <h2>Link your Locksure account</h2>
  <form method="POST" action="/alexaAuth" style="display:flex;flex-direction:column;gap:12px">
    <input type="email"    name="email"    placeholder="Email"    required style="padding:8px">
    <input type="password" name="password" placeholder="Password" required style="padding:8px">
    <input type="hidden"   name="state"        value="${state}">
    <input type="hidden"   name="redirect_uri" value="${redirect}">
    <button type="submit"  style="padding:10px 20px;font-size:16px">Sign in</button>
  </form>
</body></html>`;

/* ─────────────────────── 4. SMART HOME HELPERS ──────────────── */
const getUserIdFromToken = async (accessToken) => {
  // For this implementation, the access_token is the user ID
  const doc = await db.collection('users').doc(accessToken).get();
  if (!doc.exists) throw new Error('Invalid access token');
  return accessToken;
};

const getLocksForUser = async (userId) => {
  const locksSnapshot = await db.collection('users').doc(userId).collection('locks').get();
  const locks = [];
  locksSnapshot.forEach(doc => {
    locks.push({
      id: doc.id,
      ...doc.data()
    });
  });
  return locks;
};

const getLockState = async (userId, lockId) => {
  const lockDoc = await db.collection('users').doc(userId).collection('locks').doc(lockId).get();
  if (!lockDoc.exists) throw new Error('Lock not found');
  return lockDoc.data();
};

const setLockState = async (userId, lockId, isLocked) => {
  await db.collection('users').doc(userId).collection('locks').doc(lockId).update({
    isLocked,
    lastUpdated: admin.firestore.FieldValue.serverTimestamp()
  });
};

/* ───────────────────────── 5. HANDLERS ──────────────────────── */

/* ---------- 5a  /alexaAuth  (GET & POST) ---------------------- */
async function alexaAuth(event) {
  const qp   = event.queryStringParameters || {};
  const body =
    event.httpMethod === 'POST'
      ? Object.fromEntries(new URLSearchParams(event.body || ''))
      : {};

  const state = qp.state || body.state;
  const redirect_uri = qp.redirect_uri || body.redirect_uri || REDIRECT_URI;
  const email = body.email;
  const password = body.password;

  log('INFO', 'alexaAuth called', { 
    method: event.httpMethod, 
    state: state ? 'present' : 'missing',
    hasCredentials: !!(email && password)
  });

  /* 1) POST with credentials → Firebase login */
  if (email && password) {
    log('INFO', 'Processing login credentials');
    const resp = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FIREBASE_API_KEY}`,
      {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, returnSecureToken: true })
      }
    );
    const json = await resp.json();
    if (!resp.ok) {
      log('ERROR', 'Firebase login failed', { error: json.error?.message });
      return { statusCode: 401, body: `Login failed: ${json.error?.message}` };
    }
    
    log('INFO', 'Firebase login successful', { uid: json.localId });
    
    // Store the user ID in Firestore for later token exchange
    const authCode = crypto.randomBytes(32).toString('hex');
    await db.collection('alexaCodes').doc(authCode).set({
      uid: json.localId,
      state: state,
      used: false,
      expires: Date.now() + 5 * 60 * 1000 // 5 minutes
    });
    
    log('INFO', 'Auth code stored', { authCode, uid: json.localId });
    
    // Redirect back to Alexa with our auth code
    const successUrl = `https://layla.amazon.com/api/skill/link/${SKILL_ID}?code=${encodeURIComponent(authCode)}&state=${encodeURIComponent(state)}`;
    
      return {
        statusCode: 302,
      headers: { Location: successUrl, 'Cache-Control': 'no-cache' },
        body: ''
      };
  }

  /* 2) GET request - show login page */
  log('INFO', 'Showing login page');
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'text/html' },
    body: htmlLogin(state, redirect_uri)
  };
}

/* ---------- 5b  /alexaToken  (POST) --------------------------- */
async function alexaToken(event) {
  const body = Object.fromEntries(new URLSearchParams(event.body || ''));
  const { code, state } = body;
  
  log('INFO', 'alexaToken called', { 
    hasCode: !!code, 
    hasState: !!state,
    code: code ? code.substring(0, 8) + '...' : 'none'
  });

  if (!code || !state) {
    log('ERROR', 'Missing code or state');
      return {
      statusCode: 400, 
        headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'missing_code_or_state' }) 
    };
  }

  // Look up the auth code in Firestore
  const doc = await db.collection('alexaCodes').doc(code).get();
  if (!doc.exists) {
    log('ERROR', 'Auth code not found', { code: code.substring(0, 8) + '...' });
    return {
      statusCode: 400, 
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'invalid_code' }) 
    };
  }
  
  const data = doc.data();
  log('INFO', 'Auth code found', { 
    uid: data.uid, 
    used: data.used, 
    stateMatch: data.state === state 
  });
  
  if (data.used) {
    log('ERROR', 'Auth code already used');
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'code_already_used' }) 
    };
  }
  
  if (data.state !== state) {
    log('ERROR', 'State mismatch', { 
      expected: data.state, 
      received: state 
    });
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'state_mismatch' }) 
    };
  }

  // Mark code as used
  await doc.ref.update({ used: true, usedAt: Date.now() });
  
  log('INFO', 'Token exchange successful', { uid: data.uid });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
      access_token: data.uid,
        token_type: 'bearer',
        expires_in: 3600
      })
    };
}

/* ---------- 5c  /smart-home  (POST) - Smart Home Skill -------- */
async function smartHome(event) {
  try {
    const directive = JSON.parse(event.body);
    log('INFO', 'Smart Home directive received', { directive });

    const { header, payload } = directive;
    const { namespace, name } = header;

    // Get user ID from authorization
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Unauthorized' })
      };
    }

    const accessToken = authHeader.substring(7);
    const userId = await getUserIdFromToken(accessToken);

    // Handle different directive types
    if (namespace === 'Alexa.Discovery' && name === 'Discover') {
      return await handleDiscovery(userId);
    } else if (namespace === 'Alexa.LockController') {
      return await handleLockController(userId, header, payload);
    } else {
      log('WARN', 'Unsupported directive', { namespace, name });
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Unsupported directive' })
      };
    }
  } catch (error) {
    log('ERROR', 'Smart Home error', { error: error.message, stack: error.stack });
        return {
          statusCode: 500,
          headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
}

async function handleDiscovery(userId) {
  const locks = await getLocksForUser(userId);
  
  const endpoints = locks.map(lock => ({
    endpointId: lock.id,
        manufacturerName: 'Locksure',
    description: lock.name || 'Smart Lock',
    friendlyName: lock.name || 'Front Door Lock',
        displayCategories: ['SMARTLOCK'],
        capabilities: [
      {
        type: 'AlexaInterface',
        interface: 'Alexa.LockController',
        version: '3',
        properties: {
          supported: [{ name: 'lockState' }],
          proactivelyReported: true,
          retrievable: true
        }
      }
        ]
      }));

      const response = {
        event: {
          header: {
            namespace: 'Alexa.Discovery',
            name: 'Discover.Response',
            payloadVersion: '3',
        messageId: crypto.randomBytes(16).toString('hex')
          },
          payload: {
        endpoints
          }
        }
      };

      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(response)
      };
}

async function handleLockController(userId, header, payload) {
  const { name } = header;
  const { endpointId } = payload;

  if (name === 'Lock') {
    await setLockState(userId, endpointId, true);
    log('INFO', 'Lock command executed', { userId, endpointId, action: 'lock' });
  } else if (name === 'Unlock') {
    await setLockState(userId, endpointId, false);
    log('INFO', 'Unlock command executed', { userId, endpointId, action: 'unlock' });
  } else {
    log('WARN', 'Unsupported lock command', { name });
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Unsupported command' })
    };
  }

  // Get current state
  const lockState = await getLockState(userId, endpointId);
  
  const response = {
    context: {
      properties: [
        {
          namespace: 'Alexa.LockController',
          name: 'lockState',
          value: lockState.isLocked ? 'LOCKED' : 'UNLOCKED',
          timeOfSample: new Date().toISOString(),
          uncertaintyInMilliseconds: 0
        }
      ]
    },
      event: {
        header: {
        namespace: 'Alexa',
        name: 'Response',
          payloadVersion: '3',
        messageId: crypto.randomBytes(16).toString('hex'),
        correlationToken: header.correlationToken
      },
      endpoint: {
        endpointId
      },
      payload: {}
    }
  };

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(response)
    };
  }

/* ───────────────────────── 6. LAMBDA ENTRY ──────────────────── */
exports.handler = async (event) => {
  if (event.directive) {
    // Handle Alexa Smart Home directive
    // e.g., Discovery, Control, etc.
    return await smartHome(event);
  } else {
    // Optionally handle other events or return an error
    return { statusCode: 404, body: 'Not found' };
  }
};

/* ─────────────────── 7. GLOBAL ERROR HANDLERS ───────────────── */
process.on('uncaughtException', err => log('FATAL', 'uncaught', err.message));
process.on('unhandledRejection', r => log('FATAL', 'unhandled', r));